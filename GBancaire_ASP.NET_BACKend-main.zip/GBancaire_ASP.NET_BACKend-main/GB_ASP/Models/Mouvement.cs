﻿namespace GB_ASP.Models
{
    public class Mouvement
    {
        
    public int id { get; set; }
        public int compte_id { get; set; }
        public float montant { get; set; }
        public DateTime date_mvt { get; set; }
    
}
}
