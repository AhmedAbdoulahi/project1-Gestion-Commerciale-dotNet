﻿ namespace GB_ASP.Models
{
    public class Compte
    {

        public int Id { get; set; }
        public float solde { get; set; }
        public string? nom { get; set; }
    }
}
