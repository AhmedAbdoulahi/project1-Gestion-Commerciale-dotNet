﻿namespace GB_ASP.Models
{
    public class response
    {
        public int Statuscode { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
